using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace ReduCycle.WinForms
{
    public partial class Form1 : Form
    {
        private SerialPort? serialPort;

        private int elapsedSeconds = 0;
        private int completedCycles = 0;
        private int currentCycle = 0;
        private int demoStep = 0;

        public Form1()
        {
            InitializeComponent();

            processTimer.Interval = 1000;
            processTimer.Tick += ProcessTimer_Tick;

            demoTimer.Interval = 3000;
            demoTimer.Tick += DemoTimer_Tick;

            LoadAvailablePorts();

            ResetDashboard();
        }

        // =========================================================
        // START
        // =========================================================

        private void btnStart_Click(object sender, EventArgs e)
        {
            currentCycle++;

            lblCurrentCycle.Text =
                currentCycle.ToString();

            lblSystemStatus.Text =
                "RUNNING";

            elapsedSeconds = 0;
            demoStep = 0;

            processTimer.Start();
            demoTimer.Start();

            lblCurrentProcess.Text =
                "Paper Input";

            lblPaperStep.Text =
                "✓ Paper Input";

            lblPaperDetection.Text =
                "Detected";
        }

        // =========================================================
        // STOP
        // =========================================================

        private void btnStop_Click(object sender, EventArgs e)
        {
            processTimer.Stop();
            demoTimer.Stop();

            lblSystemStatus.Text =
                "STOPPED";

            lblCurrentProcess.Text =
                "Process stopped";
        }

        // =========================================================
        // RESET
        // =========================================================

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetDashboard();
        }

        private void ResetDashboard()
        {
            processTimer.Stop();
            demoTimer.Stop();

            elapsedSeconds = 0;
            demoStep = 0;

            lblSystemStatus.Text =
                "READY";

            lblCurrentProcess.Text =
                "Waiting for paper...";

            lblProcessingTime.Text =
                "00:00";

            lblWaterLevel.Text =
                "0%";

            lblPaperDetection.Text =
                "Not Detected";

            lblPumpStatus.Text =
                "OFF";

            lblMotorStatus.Text =
                "OFF";

            lblPressStatus.Text =
                "IDLE";

            lblPaperStep.Text =
                "○ Paper Input";

            lblSoakingStep.Text =
                "○ Soaking & Pulping";

            lblWaterRemovalStep.Text =
                "○ Water Removal";

            lblSheetFormationStep.Text =
                "○ Sheet Formation";

            lblDryingStep.Text =
                "○ Drying";
        }

        // =========================================================
        // PROCESS TIMER
        // =========================================================

        private void ProcessTimer_Tick(object sender, EventArgs e)
        {
            elapsedSeconds++;

            int minutes =
                elapsedSeconds / 60;

            int seconds =
                elapsedSeconds % 60;

            lblProcessingTime.Text =
                $"{minutes:00}:{seconds:00}";
        }

        // =========================================================
        // DEMO TIMER
        // =========================================================

        private void DemoTimer_Tick(object sender, EventArgs e)
        {
            demoStep++;

            switch (demoStep)
            {
                case 1:

                    lblCurrentProcess.Text =
                        "Soaking & Pulping";

                    lblSoakingStep.Text =
                        "→ Soaking & Pulping";

                    lblWaterLevel.Text =
                        "75%";

                    lblPumpStatus.Text =
                        "ON";

                    lblMotorStatus.Text =
                        "ON";

                    break;

                case 2:

                    lblCurrentProcess.Text =
                        "Water Removal";

                    lblSoakingStep.Text =
                        "✓ Soaking & Pulping";

                    lblWaterRemovalStep.Text =
                        "→ Water Removal";

                    lblPumpStatus.Text =
                        "OFF";

                    lblMotorStatus.Text =
                        "OFF";

                    lblPressStatus.Text =
                        "ACTIVE";

                    break;

                case 3:

                    lblCurrentProcess.Text =
                        "Sheet Formation";

                    lblWaterRemovalStep.Text =
                        "✓ Water Removal";

                    lblSheetFormationStep.Text =
                        "→ Sheet Formation";

                    break;

                case 4:

                    lblCurrentProcess.Text =
                        "Drying";

                    lblSheetFormationStep.Text =
                        "✓ Sheet Formation";

                    lblDryingStep.Text =
                        "→ Drying";

                    lblPressStatus.Text =
                        "IDLE";

                    break;

                case 5:

                    lblDryingStep.Text =
                        "✓ Drying";

                    lblCurrentProcess.Text =
                        "Cycle completed";

                    lblSystemStatus.Text =
                        "READY";

                    completedCycles++;

                    lblCompletedCycles.Text =
                        completedCycles.ToString();

                    processTimer.Stop();
                    demoTimer.Stop();

                    break;
            }
        }

        // =========================================================
        // COM PORT
        // =========================================================

        private void LoadAvailablePorts()
        {
            cmbComPort.Items.Clear();

            string[] ports =
                SerialPort.GetPortNames();

            foreach (string port in ports)
            {
                cmbComPort.Items.Add(port);
            }

            if (cmbComPort.Items.Count > 0)
            {
                cmbComPort.SelectedIndex = 0;
            }
        }

        // =========================================================
        // CONNECT
        // =========================================================

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (cmbComPort.SelectedItem == null)
            {
                MessageBox.Show(
                    "Please select a COM port.",
                    "ReduCycle");

                return;
            }

            try
            {
                serialPort = new SerialPort(
                    cmbComPort.SelectedItem.ToString(),
                    115200);

                serialPort.Open();

                lblConnection.Text =
                    "● ESP32 CONNECTED";

                lblConnection.ForeColor =
                    System.Drawing.Color.Green;

                btnConnect.Text =
                    "DISCONNECT";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Connection failed:\n\n" +
                    ex.Message,
                    "ReduCycle");
            }
        }

        // =========================================================
        // DEMO MODE
        // =========================================================

        private void chkDemoMode_CheckedChanged(
            object sender,
            EventArgs e)
        {
            if (chkDemoMode.Checked)
            {
                lblConnection.Text =
                    "● DEMO MODE";

                lblConnection.ForeColor =
                    System.Drawing.Color.DarkOrange;
            }
            else
            {
                lblConnection.Text =
                    "● NOT CONNECTED";

                lblConnection.ForeColor =
                    System.Drawing.Color.Firebrick;
            }
        }
    }
}
