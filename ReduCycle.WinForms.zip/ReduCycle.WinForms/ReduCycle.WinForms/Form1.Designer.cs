﻿namespace ReduCycle.WinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblTitle = new Label();
            lblSubTitle = new Label();
            lblConnection = new Label();
            pnlSystemStatus = new Panel();
            label1 = new Label();
            lblSystemStatus = new Label();
            label2 = new Label();
            pnlCurrentProcess = new Panel();
            lblProcessingTime = new Label();
            lblCurrentProcess = new Label();
            label5 = new Label();
            panel1 = new Panel();
            lblPaperStep = new Label();
            panel3 = new Panel();
            lblWaterRemovalStep = new Label();
            panel2 = new Panel();
            lblSoakingStep = new Label();
            panel6 = new Panel();
            lblSheetFormationStep = new Label();
            panel7 = new Panel();
            lblDryingStep = new Label();
            panel8 = new Panel();
            lblWaterLevel = new Label();
            label8 = new Label();
            label11 = new Label();
            label7 = new Label();
            panel9 = new Panel();
            lblPaperDetection = new Label();
            label13 = new Label();
            panel10 = new Panel();
            lblPumpStatus = new Label();
            label14 = new Label();
            panel4 = new Panel();
            lblMotorStatus = new Label();
            label9 = new Label();
            panel5 = new Panel();
            lblPressStatus = new Label();
            label10 = new Label();
            btnStart = new Button();
            btnStop = new Button();
            btnReset = new Button();
            label12 = new Label();
            cmbComPort = new ComboBox();
            btnConnect = new Button();
            chkDemoMode = new CheckBox();
            label15 = new Label();
            lblCompletedCycles = new Label();
            lblCurrentCycle = new Label();
            processTimer = new System.Windows.Forms.Timer(components);
            demoTimer = new System.Windows.Forms.Timer(components);
            label6 = new Label();
            pnlSystemStatus.SuspendLayout();
            pnlCurrentProcess.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.DarkGreen;
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(294, 65);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "REDUCYCLE";
            // 
            // lblSubTitle
            // 
            lblSubTitle.AutoSize = true;
            lblSubTitle.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSubTitle.ForeColor = Color.DarkGreen;
            lblSubTitle.Location = new Point(21, 74);
            lblSubTitle.Name = "lblSubTitle";
            lblSubTitle.Size = new Size(319, 28);
            lblSubTitle.TabIndex = 1;
            lblSubTitle.Text = "Automated Paper Recycling System";
            // 
            // lblConnection
            // 
            lblConnection.AutoSize = true;
            lblConnection.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblConnection.ForeColor = Color.DarkOrange;
            lblConnection.Location = new Point(910, 46);
            lblConnection.Name = "lblConnection";
            lblConnection.Size = new Size(156, 28);
            lblConnection.TabIndex = 2;
            lblConnection.Text = "● DEMO MODE";
            // 
            // pnlSystemStatus
            // 
            pnlSystemStatus.BorderStyle = BorderStyle.FixedSingle;
            pnlSystemStatus.Controls.Add(label1);
            pnlSystemStatus.Controls.Add(lblSystemStatus);
            pnlSystemStatus.Controls.Add(label2);
            pnlSystemStatus.Location = new Point(21, 131);
            pnlSystemStatus.Name = "pnlSystemStatus";
            pnlSystemStatus.Size = new Size(350, 140);
            pnlSystemStatus.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(30, 105);
            label1.Name = "label1";
            label1.Size = new Size(289, 28);
            label1.TabIndex = 6;
            label1.Text = "System ready for recycling cycle";
            // 
            // lblSystemStatus
            // 
            lblSystemStatus.AutoSize = true;
            lblSystemStatus.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSystemStatus.ForeColor = Color.Black;
            lblSystemStatus.Location = new Point(18, 40);
            lblSystemStatus.Name = "lblSystemStatus";
            lblSystemStatus.Size = new Size(184, 65);
            lblSystemStatus.TabIndex = 5;
            lblSystemStatus.Text = "READY";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(18, 12);
            label2.Name = "label2";
            label2.Size = new Size(166, 28);
            label2.TabIndex = 4;
            label2.Text = "SYSTEM STATUS";
            // 
            // pnlCurrentProcess
            // 
            pnlCurrentProcess.BorderStyle = BorderStyle.FixedSingle;
            pnlCurrentProcess.Controls.Add(lblProcessingTime);
            pnlCurrentProcess.Controls.Add(lblCurrentProcess);
            pnlCurrentProcess.Controls.Add(label5);
            pnlCurrentProcess.Location = new Point(716, 131);
            pnlCurrentProcess.Name = "pnlCurrentProcess";
            pnlCurrentProcess.Size = new Size(350, 140);
            pnlCurrentProcess.TabIndex = 7;
            // 
            // lblProcessingTime
            // 
            lblProcessingTime.AutoSize = true;
            lblProcessingTime.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblProcessingTime.ForeColor = Color.Black;
            lblProcessingTime.Location = new Point(18, 105);
            lblProcessingTime.Name = "lblProcessingTime";
            lblProcessingTime.Size = new Size(60, 28);
            lblProcessingTime.TabIndex = 6;
            lblProcessingTime.Text = "00:00";
            // 
            // lblCurrentProcess
            // 
            lblCurrentProcess.AutoSize = true;
            lblCurrentProcess.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentProcess.ForeColor = Color.Black;
            lblCurrentProcess.Location = new Point(18, 49);
            lblCurrentProcess.Name = "lblCurrentProcess";
            lblCurrentProcess.Size = new Size(272, 38);
            lblCurrentProcess.TabIndex = 5;
            lblCurrentProcess.Text = "Waiting for paper...";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(18, 12);
            label5.Name = "label5";
            label5.Size = new Size(194, 28);
            label5.TabIndex = 4;
            label5.Text = "CURRENT PROCESS";
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblPaperStep);
            panel1.Location = new Point(21, 356);
            panel1.Name = "panel1";
            panel1.Size = new Size(198, 111);
            panel1.TabIndex = 7;
            // 
            // lblPaperStep
            // 
            lblPaperStep.AutoSize = true;
            lblPaperStep.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPaperStep.ForeColor = Color.Black;
            lblPaperStep.Location = new Point(21, 38);
            lblPaperStep.Name = "lblPaperStep";
            lblPaperStep.Size = new Size(133, 25);
            lblPaperStep.TabIndex = 4;
            lblPaperStep.Text = "○ Paper Input\n";
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(lblWaterRemovalStep);
            panel3.Location = new Point(504, 356);
            panel3.Name = "panel3";
            panel3.Size = new Size(180, 111);
            panel3.TabIndex = 8;
            // 
            // lblWaterRemovalStep
            // 
            lblWaterRemovalStep.AutoSize = true;
            lblWaterRemovalStep.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblWaterRemovalStep.ForeColor = Color.Black;
            lblWaterRemovalStep.Location = new Point(3, 38);
            lblWaterRemovalStep.Name = "lblWaterRemovalStep";
            lblWaterRemovalStep.Size = new Size(163, 25);
            lblWaterRemovalStep.TabIndex = 4;
            lblWaterRemovalStep.Text = "○ Water Removal\n";
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(lblSoakingStep);
            panel2.Location = new Point(240, 356);
            panel2.Name = "panel2";
            panel2.Size = new Size(247, 111);
            panel2.TabIndex = 8;
            // 
            // lblSoakingStep
            // 
            lblSoakingStep.AutoSize = true;
            lblSoakingStep.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblSoakingStep.ForeColor = Color.Black;
            lblSoakingStep.Location = new Point(14, 38);
            lblSoakingStep.Name = "lblSoakingStep";
            lblSoakingStep.Size = new Size(208, 25);
            lblSoakingStep.TabIndex = 4;
            lblSoakingStep.Text = "○ Soaking and Pulping";
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(lblSheetFormationStep);
            panel6.Location = new Point(704, 356);
            panel6.Name = "panel6";
            panel6.Size = new Size(187, 112);
            panel6.TabIndex = 9;
            // 
            // lblSheetFormationStep
            // 
            lblSheetFormationStep.AutoSize = true;
            lblSheetFormationStep.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblSheetFormationStep.ForeColor = Color.Black;
            lblSheetFormationStep.Location = new Point(3, 38);
            lblSheetFormationStep.Name = "lblSheetFormationStep";
            lblSheetFormationStep.Size = new Size(173, 25);
            lblSheetFormationStep.TabIndex = 4;
            lblSheetFormationStep.Text = "○ Sheet Formation";
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Controls.Add(lblDryingStep);
            panel7.Location = new Point(912, 355);
            panel7.Name = "panel7";
            panel7.Size = new Size(154, 112);
            panel7.TabIndex = 10;
            // 
            // lblDryingStep
            // 
            lblDryingStep.AutoSize = true;
            lblDryingStep.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblDryingStep.ForeColor = Color.Black;
            lblDryingStep.Location = new Point(35, 39);
            lblDryingStep.Name = "lblDryingStep";
            lblDryingStep.Size = new Size(91, 25);
            lblDryingStep.TabIndex = 4;
            lblDryingStep.Text = "○ Drying";
            // 
            // panel8
            // 
            panel8.BorderStyle = BorderStyle.FixedSingle;
            panel8.Controls.Add(lblWaterLevel);
            panel8.Controls.Add(label8);
            panel8.Location = new Point(21, 544);
            panel8.Name = "panel8";
            panel8.Size = new Size(173, 140);
            panel8.TabIndex = 7;
            // 
            // lblWaterLevel
            // 
            lblWaterLevel.AutoSize = true;
            lblWaterLevel.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblWaterLevel.ForeColor = Color.Black;
            lblWaterLevel.Location = new Point(18, 74);
            lblWaterLevel.Name = "lblWaterLevel";
            lblWaterLevel.Size = new Size(39, 28);
            lblWaterLevel.TabIndex = 6;
            lblWaterLevel.Text = "0%";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(18, 20);
            label8.Name = "label8";
            label8.Size = new Size(129, 25);
            label8.TabIndex = 5;
            label8.Text = "WATER LEVEL";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(21, 495);
            label11.Name = "label11";
            label11.Size = new Size(293, 32);
            label11.TabIndex = 11;
            label11.Text = "MACHINE MONITORING";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(7, 20);
            label7.Name = "label7";
            label7.Size = new Size(173, 25);
            label7.TabIndex = 5;
            label7.Text = "PAPER DETECTION";
            // 
            // panel9
            // 
            panel9.BorderStyle = BorderStyle.FixedSingle;
            panel9.Controls.Add(lblPaperDetection);
            panel9.Controls.Add(label13);
            panel9.Location = new Point(226, 544);
            panel9.Name = "panel9";
            panel9.Size = new Size(186, 140);
            panel9.TabIndex = 8;
            // 
            // lblPaperDetection
            // 
            lblPaperDetection.AutoSize = true;
            lblPaperDetection.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPaperDetection.ForeColor = Color.Black;
            lblPaperDetection.Location = new Point(18, 74);
            lblPaperDetection.Name = "lblPaperDetection";
            lblPaperDetection.Size = new Size(39, 28);
            lblPaperDetection.TabIndex = 6;
            lblPaperDetection.Text = "0%";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Black;
            label13.Location = new Point(3, 20);
            label13.Name = "label13";
            label13.Size = new Size(173, 25);
            label13.TabIndex = 5;
            label13.Text = "PAPER DETECTION";
            // 
            // panel10
            // 
            panel10.BorderStyle = BorderStyle.FixedSingle;
            panel10.Controls.Add(lblPumpStatus);
            panel10.Controls.Add(label14);
            panel10.Location = new Point(456, 544);
            panel10.Name = "panel10";
            panel10.Size = new Size(186, 140);
            panel10.TabIndex = 9;
            // 
            // lblPumpStatus
            // 
            lblPumpStatus.AutoSize = true;
            lblPumpStatus.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPumpStatus.ForeColor = Color.Black;
            lblPumpStatus.Location = new Point(63, 74);
            lblPumpStatus.Name = "lblPumpStatus";
            lblPumpStatus.Size = new Size(47, 28);
            lblPumpStatus.TabIndex = 6;
            lblPumpStatus.Text = "OFF";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.Black;
            label14.Location = new Point(29, 20);
            label14.Name = "label14";
            label14.Size = new Size(131, 25);
            label14.TabIndex = 5;
            label14.Text = "WATER PUMP";
            // 
            // panel4
            // 
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(lblMotorStatus);
            panel4.Controls.Add(label9);
            panel4.Location = new Point(694, 544);
            panel4.Name = "panel4";
            panel4.Size = new Size(186, 140);
            panel4.TabIndex = 10;
            // 
            // lblMotorStatus
            // 
            lblMotorStatus.AutoSize = true;
            lblMotorStatus.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMotorStatus.ForeColor = Color.Black;
            lblMotorStatus.Location = new Point(71, 85);
            lblMotorStatus.Name = "lblMotorStatus";
            lblMotorStatus.Size = new Size(47, 28);
            lblMotorStatus.TabIndex = 7;
            lblMotorStatus.Text = "OFF";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(13, 20);
            label9.Name = "label9";
            label9.Size = new Size(160, 25);
            label9.TabIndex = 5;
            label9.Text = "PULPING MOTOR";
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(lblPressStatus);
            panel5.Controls.Add(label10);
            panel5.Location = new Point(922, 544);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 140);
            panel5.TabIndex = 11;
            // 
            // lblPressStatus
            // 
            lblPressStatus.AutoSize = true;
            lblPressStatus.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPressStatus.ForeColor = Color.Black;
            lblPressStatus.Location = new Point(53, 85);
            lblPressStatus.Name = "lblPressStatus";
            lblPressStatus.Size = new Size(50, 28);
            lblPressStatus.TabIndex = 6;
            lblPressStatus.Text = "IDLE";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(38, 20);
            label10.Name = "label10";
            label10.Size = new Size(65, 25);
            label10.TabIndex = 5;
            label10.Text = "PRESS";
            // 
            // btnStart
            // 
            btnStart.Location = new Point(30, 727);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(112, 34);
            btnStart.TabIndex = 12;
            btnStart.Text = "START";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnStop
            // 
            btnStop.Location = new Point(163, 727);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(112, 34);
            btnStop.TabIndex = 13;
            btnStop.Text = "STOP";
            btnStop.UseVisualStyleBackColor = true;
            btnStop.Click += btnStop_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(309, 727);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(112, 34);
            btnReset.TabIndex = 14;
            btnReset.Text = "RESET";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Black;
            label12.Location = new Point(465, 732);
            label12.Name = "label12";
            label12.Size = new Size(156, 25);
            label12.TabIndex = 15;
            label12.Text = "ESP32 COM Port:";
            // 
            // cmbComPort
            // 
            cmbComPort.FormattingEnabled = true;
            cmbComPort.Location = new Point(630, 729);
            cmbComPort.Name = "cmbComPort";
            cmbComPort.Size = new Size(63, 33);
            cmbComPort.TabIndex = 16;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(716, 729);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(112, 34);
            btnConnect.TabIndex = 17;
            btnConnect.Text = "CONNECT";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // chkDemoMode
            // 
            chkDemoMode.AutoSize = true;
            chkDemoMode.Checked = true;
            chkDemoMode.CheckState = CheckState.Checked;
            chkDemoMode.Location = new Point(853, 734);
            chkDemoMode.Name = "chkDemoMode";
            chkDemoMode.Size = new Size(147, 29);
            chkDemoMode.TabIndex = 18;
            chkDemoMode.Text = "DEMO MODE";
            chkDemoMode.UseVisualStyleBackColor = true;
            chkDemoMode.Click += chkDemoMode_CheckedChanged;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(33, 802);
            label15.Name = "label15";
            label15.Size = new Size(282, 32);
            label15.TabIndex = 19;
            label15.Text = "RECYCLING STATISTICS:";
            // 
            // lblCompletedCycles
            // 
            lblCompletedCycles.AutoSize = true;
            lblCompletedCycles.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCompletedCycles.ForeColor = Color.Black;
            lblCompletedCycles.Location = new Point(33, 853);
            lblCompletedCycles.Name = "lblCompletedCycles";
            lblCompletedCycles.Size = new Size(173, 25);
            lblCompletedCycles.TabIndex = 20;
            lblCompletedCycles.Text = "Completed Cycles: 0\r\n";
            // 
            // lblCurrentCycle
            // 
            lblCurrentCycle.AutoSize = true;
            lblCurrentCycle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCurrentCycle.ForeColor = Color.Black;
            lblCurrentCycle.Location = new Point(33, 890);
            lblCurrentCycle.Name = "lblCurrentCycle";
            lblCurrentCycle.Size = new Size(135, 25);
            lblCurrentCycle.TabIndex = 21;
            lblCurrentCycle.Text = "Current Cycle: 0\r\n";
            // 
            // processTimer
            // 
            processTimer.Interval = 1000;
            // 
            // demoTimer
            // 
            demoTimer.Interval = 3000;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(39, 304);
            label6.Name = "label6";
            label6.Size = new Size(253, 32);
            label6.TabIndex = 22;
            label6.Text = "RECYCLING PROCESS";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1078, 941);
            Controls.Add(label6);
            Controls.Add(lblCurrentCycle);
            Controls.Add(lblCompletedCycles);
            Controls.Add(label15);
            Controls.Add(chkDemoMode);
            Controls.Add(btnConnect);
            Controls.Add(cmbComPort);
            Controls.Add(label12);
            Controls.Add(btnReset);
            Controls.Add(btnStop);
            Controls.Add(btnStart);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel10);
            Controls.Add(panel9);
            Controls.Add(label11);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(pnlCurrentProcess);
            Controls.Add(pnlSystemStatus);
            Controls.Add(lblConnection);
            Controls.Add(lblSubTitle);
            Controls.Add(lblTitle);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ReduCycle - Automated Paper Recycling System";
            pnlSystemStatus.ResumeLayout(false);
            pnlSystemStatus.PerformLayout();
            pnlCurrentProcess.ResumeLayout(false);
            pnlCurrentProcess.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblSubTitle;
        private Label lblConnection;
        private Panel pnlSystemStatus;
        private Label label1;
        private Label lblSystemStatus;
        private Label label2;
        private Panel pnlCurrentProcess;
        private Label lblProcessingTime;
        private Label lblCurrentProcess;
        private Label label5;
        private Panel panel1;
        private Label lblPaperStep;
        private Label lblCompletedCycles;
        private Panel panel3;
        private Label lblWaterRemovalStep;
        private Panel panel4;
        private Label label9;
        private Panel panel5;
        private Label label10;
        private Panel panel2;
        private Label lblSoakingStep;
        private Panel panel6;
        private Label lblSheetFormationStep;
        private Panel panel7;
        private Label lblDryingStep;
        private Panel panel8;
        private Label lblWaterLevel;
        private Label label8;
        private Label label11;
        private Label label7;
        private Panel panel9;
        private Label lblPaperDetection;
        private Label label13;
        private Panel panel10;
        private Label lblPumpStatus;
        private Label label14;
        private Label lblPressStatus;
        private Label lblMotorStatus;
        private Button btnStart;
        private Button btnStop;
        private Button btnReset;
        private Label label12;
        private ComboBox cmbComPort;
        private Button btnConnect;
        private CheckBox chkDemoMode;
        private Label label15;
        private Label lblCurrentCycle;
        private System.Windows.Forms.Timer processTimer;
        private System.Windows.Forms.Timer demoTimer;
        private Label label6;
    }
}
